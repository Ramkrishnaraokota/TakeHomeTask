package com.assignment;

import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class CronUtilTest {
	
	CronUtil cronutil = new CronUtil();
	
	// Test minutes - valid
	
	 //0-59
	 // */10
	// 10,28,39,68	
	
	@Test
	void testMinutesValidSSingleInput() throws InvalidCronExpressionException {
		String minutesString = "4";
		Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.MINUTES);
		String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
		Assertions.assertEquals("4", outputString);
	}
	
	@Test
	void testMinutesInValidSSingleInput() throws InvalidCronExpressionException {
		String minutesString = "400";
		Assertions.assertThrows(InvalidCronExpressionException.class, ()-> cronutil.parseCronInput(minutesString, FieldType.MINUTES));
	}
	@Test
	void testMinutesValidCronInput() throws InvalidCronExpressionException {
		String minutesString = "*/15";
		Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.MINUTES);
		String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
		Assertions.assertEquals("0 15 30 45", outputString);
	}
	
	@Test
	void testMinutesValidRangeCronInput() throws InvalidCronExpressionException {
		String minutesString = "10-15";
		Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.MINUTES);
		String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
		Assertions.assertEquals("10 11 12 13 14 15", outputString);
	}
	
	@Test
	void testMinutesValidListCronInput() throws InvalidCronExpressionException {
		String minutesString = "10,28,39";
		Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.MINUTES);
		String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
		Assertions.assertEquals("10 28 39", outputString);
	}
	
	@Test
	void testMinutesInValidListCronInput() throws InvalidCronExpressionException {
		String minutesString = "10,28,39,63";
		Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.MINUTES);
		String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
		System.out.println(outputString);
		Assertions.assertEquals("10 28 39", outputString);
	}
	
	
	// Test minutes - invalid minimum/maximum
		@Test
		void testMinutesInvalidMaxCronInput() throws InvalidCronExpressionException {
			String minutesString = "0-90";
			Assertions.assertThrows(InvalidCronExpressionException.class, ()-> cronutil.parseCronInput(minutesString, FieldType.MINUTES));
		}
		
	// test Minutes interval outside the min max range
	// expected to print first value
		@Test
		void testMinutesInvalidIntervalCronInput() throws InvalidCronExpressionException {
			String minutesString = "*/80";
			Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.MINUTES);
			String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
			Assertions.assertEquals("0", outputString);
		}
		
		// Test invalid number format exception
		@Test
		void testMinutesNumberFormatIntervalCronInput() throws InvalidCronExpressionException {
			String minutesString = "*/x";
			Assertions.assertThrows(InvalidCronExpressionException.class, ()-> cronutil.parseCronInput(minutesString, FieldType.MINUTES));
		}
		
		
		
		// Hours Test cases 
		// Valid Hours 15 0-23, */3, 9,19,21
		
		@Test
		void testHoursValidSingleCronInput() throws InvalidCronExpressionException {
			String minutesString = "15";
			Set<Integer> outputList = cronutil.parseCronInput(minutesString, FieldType.HOURS);
			String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
			Assertions.assertEquals("15", outputString);
		}
		
		@Test
		void testHoursValidRangeCronInput() throws InvalidCronExpressionException {
			String hoursString = "0-5";
			Set<Integer> outputList = cronutil.parseCronInput(hoursString, FieldType.HOURS);
			String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
			Assertions.assertEquals("0 1 2 3 4 5", outputString);
		}
		
		
		@Test
		void testHoursValidIntervalCronInput() throws InvalidCronExpressionException {
			String hoursString = "*/3";
			Set<Integer> outputList = cronutil.parseCronInput(hoursString, FieldType.HOURS);
			String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
			Assertions.assertEquals("0 3 6 9 12 15 18 21", outputString);
		}
		@Test
		void testHoursValidListCronInput() throws InvalidCronExpressionException {
			String hoursString = "9,19,21";
			Set<Integer> outputList = cronutil.parseCronInput(hoursString, FieldType.HOURS);
			String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
			Assertions.assertEquals("9 19 21", outputString);
		}
		
		
		// Day of month Test cases 
		// Valid Hours 30 , */3, 9,19,21
				
			@Test
			void testDayOfMonthValidSingleCronInput() throws InvalidCronExpressionException {
					String dayOfTheMonthString = "30";
					Set<Integer> outputList = cronutil.parseCronInput(dayOfTheMonthString, FieldType.DAY_OF_THE_MONTH);
					String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
					Assertions.assertEquals("30", outputString);
				}
		
			@Test
			void testDayOfMonthValidIntervalCronInput() throws InvalidCronExpressionException {
					String dayOfTheMonthString = "*/7";
					Set<Integer> outputList = cronutil.parseCronInput(dayOfTheMonthString, FieldType.DAY_OF_THE_MONTH);
					String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
					Assertions.assertEquals("1 8 15 22 29", outputString);
				}
			
			@Test
			void testDayOfMonthValidRangeCronInput() throws InvalidCronExpressionException {
					String dayOfTheMonthString = "15-19";
					Set<Integer> outputList = cronutil.parseCronInput(dayOfTheMonthString, FieldType.DAY_OF_THE_MONTH);
					String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
					Assertions.assertEquals("15 16 17 18 19", outputString);
				}
			
			
			@Test
			void testDayOfMonthValidListCronInput() throws InvalidCronExpressionException {
					String dayOfTheMonthString = "19,23,4,18";
					Set<Integer> outputList = cronutil.parseCronInput(dayOfTheMonthString, FieldType.DAY_OF_THE_MONTH);
					String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
					Assertions.assertEquals("4 18 19 23", outputString);
				}
			
			
			//Month test cases 
			// 3, */2, 3-5, 3,5,9
					
				@Test
				void testMonthValidSingleCronInput() throws InvalidCronExpressionException {
						String monthString = "12";
						Set<Integer> outputList = cronutil.parseCronInput(monthString, FieldType.MONTH);
						String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
						Assertions.assertEquals("12", outputString);
					}
				
				@Test
				void testMonthValidIntervalCronInput() throws InvalidCronExpressionException {
						String monthString = "*/3";
						Set<Integer> outputList = cronutil.parseCronInput(monthString, FieldType.MONTH);
						String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
						Assertions.assertEquals("1 4 7 10", outputString);
					}
				
				
				@Test
				void testMonthValidRangeCronInput() throws InvalidCronExpressionException {
						String monthString = "3-5";
						Set<Integer> outputList = cronutil.parseCronInput(monthString, FieldType.MONTH);
						String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
						Assertions.assertEquals("3 4 5", outputString);
					}
				
				@Test
				void testMonthValidListCronInput() throws InvalidCronExpressionException {
						String monthString = "3,5,9";
						Set<Integer> outputList = cronutil.parseCronInput(monthString, FieldType.MONTH);
						String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
						Assertions.assertEquals("3 5 9", outputString);
					}
			
				//Day of the week test cases 
				// 4, */2, 2-6, 1,3,4,7
						
					@Test
					void testDayOfTheWeekValidSingleCronInput() throws InvalidCronExpressionException {
							String dayOfWeekString = "4";
							Set<Integer> outputList = cronutil.parseCronInput(dayOfWeekString, FieldType.DAY_OF_THE_WEEK);
							String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
							Assertions.assertEquals("4", outputString);
						}	
		
					@Test
					void testDayOfTheWeekValidIntervalCronInput() throws InvalidCronExpressionException {
							String dayOfWeekString = "*/2";
							Set<Integer> outputList = cronutil.parseCronInput(dayOfWeekString, FieldType.DAY_OF_THE_WEEK);
							String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
							Assertions.assertEquals("1 3 5 7", outputString);
						}	
					@Test
					void testDayOfTheWeekValidRangeCronInput() throws InvalidCronExpressionException {
							String dayOfWeekString = "2-6";
							Set<Integer> outputList = cronutil.parseCronInput(dayOfWeekString, FieldType.DAY_OF_THE_WEEK);
							String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
							Assertions.assertEquals("2 3 4 5 6", outputString);
						}	
					@Test
					void testDayOfTheWeekValidListCronInput() throws InvalidCronExpressionException {
							String dayOfWeekString = "1,3,4,7";
							Set<Integer> outputList = cronutil.parseCronInput(dayOfWeekString, FieldType.DAY_OF_THE_WEEK);
							String outputString = outputList.toString().replace("[", "").replace("]", "").replace(",", "");
							Assertions.assertEquals("1 3 4 7", outputString);
						}	
					
}
