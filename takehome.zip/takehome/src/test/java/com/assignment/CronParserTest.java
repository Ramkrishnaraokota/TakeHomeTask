package com.assignment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class CronParserTest {

	
	// valid String
	@Test
	void testCronParser1() throws InvalidCronExpressionException  {
		
		
		CronParser cronParser = new CronParser("*/15 0 1,15 * 1-5 /usr/bin/find");
		System.out.println(cronParser);
		Assertions.assertEquals("/usr/bin/find", cronParser.command);
	}
	
	// Invalid Strings
	@ParameterizedTest
	@ValueSource(strings = {"*/3 1,3 * 1-500 /usr/bin/find", "*/X */3 1,3 * 1-3 /usr/bin/find", "*/X */3 1,3 * 1-500 /usr/bin/find"})
	void testCronInvalidInput(String input) throws InvalidCronExpressionException  {
		
		Assertions.assertThrows(InvalidCronExpressionException.class, ()->  new CronParser(input));
	}
	
	
	

}
