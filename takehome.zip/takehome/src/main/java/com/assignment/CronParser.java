package com.assignment;

import static java.lang.String.format;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CronParser {
	
	
	
	Map<String, Set<Integer>> mapOfSegments;
	String expression;
	String command;
		
	/**
	 * @param expression
	 * @throws InvalidCronExpressionException
	 */
	public CronParser(String expression) throws InvalidCronExpressionException {
		this.expression = expression;
		this.mapOfSegments = new LinkedHashMap<>();
		this.parseTheExpression();
	}


	/**
	 * @return The Cron Expression object
	 * @throws InvalidCronExpressionException
	 */
	private CronParser parseTheExpression() throws InvalidCronExpressionException {
		
		CronUtil cronUtil = new CronUtil();
		if(expression != null) {
			
			// 
			String[] arrayOfSegments = expression.split(" ");
			if(arrayOfSegments.length == 6) {
				mapOfSegments.put("minute", cronUtil.parseCronInput(arrayOfSegments[0], FieldType.MINUTES));
				mapOfSegments.put("hour", cronUtil.parseCronInput(arrayOfSegments[1], FieldType.HOURS));
				mapOfSegments.put("day of month", cronUtil.parseCronInput(arrayOfSegments[2], FieldType.DAY_OF_THE_MONTH));
				mapOfSegments.put("month", cronUtil.parseCronInput(arrayOfSegments[3], FieldType.MONTH));
				mapOfSegments.put("day of week", cronUtil.parseCronInput(arrayOfSegments[4], FieldType.DAY_OF_THE_WEEK));
				
				command = arrayOfSegments[5];
				
				
			}
			else {
				throw new InvalidCronExpressionException("Expected in put with 6 fields and a command but revieved :"+expression);
			}
		}
		return this;
		
	}
	
	
	 /**
	 *To String method to print the parsed input cron string
	 */
	public String toString() {
	        StringBuilder buffer = new StringBuilder();
	        
	        for(Entry<String, Set<Integer>> eachEntry : mapOfSegments.entrySet()) {
	        	buffer.append(format("%-14s%s%n", eachEntry.getKey(), 
	        			eachEntry.getValue().toString().replace("[", "")).replace("]", "").replace(",", ""));
	        }			
	        buffer.append(format("%-14s%s%n", "command", command));
	        return buffer.toString();
	    }
	
	

}