package com.assignment;

import java.util.Arrays;

public class CronJobParserMain {
	public static void main(String[] args) throws InvalidCronExpressionException {

		if(args.length != 1) {
			System.err.println("Expected the input [minute] [hour] [day of month] [month] [day of week] [command] instead input recieved is "+ Arrays.toString(args));
		}
		
		CronParser cronParser = new CronParser(args[0]);
		
		System.out.println(cronParser.toString());
	}

}

