package com.assignment;

public class CronConstants {
	
	static final String DELIMITER_COMMA = ",";
	static final String DELIMITER_HYPHEN = "-";
	static final String DELIMITER_STAR = "*";
	static final String DELIMITER_SLASH = "/";

}
