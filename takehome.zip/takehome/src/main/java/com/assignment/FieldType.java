package com.assignment;

public enum FieldType {
	
	MINUTES(0,59),
	HOURS(0,23),
	DAY_OF_THE_MONTH(1,31),
	MONTH(1,12),
	DAY_OF_THE_WEEK(1,7);
	
	
	 int minimum;
	 int maximum;
	
	private FieldType(int minimum, int maximum) {
		this.minimum = minimum;
		this.maximum = maximum;
	}
}
