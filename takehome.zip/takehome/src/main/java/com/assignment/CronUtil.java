package com.assignment;


import java.util.Set;
import java.util.TreeSet;

public class CronUtil {

	

	/**
	 * This Method verifies the delimiter in a cron parser and routes to respective Parsing method.
	 * @param inputCronField
	 * @param fieldType
	 * @return
	 * @throws InvalidCronExpressionException
	 */
	public Set<Integer> parseCronInput(String inputCronField, FieldType fieldType) throws InvalidCronExpressionException {
		Set<Integer> parsedValues = null;
		// Parse Fixed values
		if(inputCronField.contains(CronConstants.DELIMITER_COMMA)) {
			parsedValues = parseFixedCronFieldValues(inputCronField, fieldType);
		}
					
		// Parse Range of values 
		if(inputCronField.contains(CronConstants.DELIMITER_HYPHEN)) {
			parsedValues = parseRangeOfCronFieldValues(inputCronField, fieldType);
		}
		
		// Parse intervals
		if(inputCronField.contains(CronConstants.DELIMITER_STAR)) {
			parsedValues = parseCronFieldIntervals(inputCronField, fieldType);
		}
		
		if(parsedValues == null) {
			parsedValues = new TreeSet<>();
			// if the single value is less than max and greater then min then accept
			if(parseNumber(inputCronField) >= fieldType.minimum && parseNumber(inputCronField) <= fieldType.maximum ) {
				parsedValues.add(parseNumber(inputCronField));
			}else {
				throw new InvalidCronExpressionException("Input Value in the Cron field is out of range :"+ inputCronField);
			}
		}
		
		return parsedValues;
	}

	/**
	 * This Method is used to parse Input fields with * 
	 * @param inputCronField
	 * @param fieldType
	 * @return
	 * @throws InvalidCronExpressionException 
	 */
	private Set<Integer> parseCronFieldIntervals(String inputCronField, FieldType fieldType) throws InvalidCronExpressionException {
		Set<Integer> rangeValuesList = null;
		if(inputCronField.contains(CronConstants.DELIMITER_SLASH)) {
		//	*/1 = 0 15 30 45, 
		String[] interval = inputCronField.split(CronConstants.DELIMITER_SLASH);
		
		if(interval.length ==2) {
			rangeValuesList = calculateRangeOfValues(fieldType.minimum, fieldType.maximum, parseNumber(interval[1]));
		}
		else {
			throw new InvalidCronExpressionException("Invalid filed value "+ inputCronField);
		}
		}else {
			
			rangeValuesList = calculateRangeOfValues(fieldType.minimum, fieldType.maximum, 1);	
		}
		return rangeValuesList;
	}

	/**
	 * This Method is used to parse Input fields with -
	 * @param inputCronField
	 * @param fieldType
	 * @return
	 * @throws InvalidCronExpressionException
	 */
	private Set<Integer> parseRangeOfCronFieldValues(String inputCronField, FieldType fieldType) throws InvalidCronExpressionException {
		String[] rangeValues = inputCronField.split(CronConstants.DELIMITER_HYPHEN);
		// 1-7
		if(rangeValues.length != 2) {
			throw new InvalidCronExpressionException("Invalid range of values in cron Expression : "+ inputCronField);
		}
		if(parseNumber(rangeValues[0]) < fieldType.minimum || parseNumber(rangeValues[1]) > fieldType.maximum ) {
			throw new InvalidCronExpressionException("Invalid minimum or maximum values in cron Expression: "+ inputCronField);
		}
		if(parseNumber(rangeValues[0]) > parseNumber(rangeValues[1])) {
			throw new InvalidCronExpressionException("Invalid range of values in cron Expression: "+ inputCronField);
		}
		return calculateRangeOfValues(parseNumber(rangeValues[0]), parseNumber(rangeValues[1]), 1);
		
		
	}

	/**
	 * This is method is used to return the list of values based on Increment
	 * @param start
	 * @param end
	 * @param increment
	 * @return
	 */
	private Set<Integer> calculateRangeOfValues(Integer start, Integer end, int increment) {
		Set<Integer> values = new TreeSet<>();
		for (int i = start; i <= end; i += increment) {
            values.add(i);
        }
		return values;
	}

	/**
	 * This Method is used to parse Input fields with ","
	 * @param inputCronField
	 * @param fieldType
	 * @return
	 * @throws InvalidCronExpressionException
	 */
	private Set<Integer> parseFixedCronFieldValues(String inputCronField, FieldType fieldType) throws InvalidCronExpressionException {
		
		// 1 3 5 7 8- order 
		Set<Integer> parsedList = new TreeSet<>();
		String[] fixedValues = inputCronField.split(CronConstants.DELIMITER_COMMA);
		
		for(String eachFixedValue : fixedValues) {
			if(parseNumber(eachFixedValue) >= fieldType.minimum && parseNumber(eachFixedValue) <= fieldType.maximum ) {
				parsedList.add(parseNumber(eachFixedValue));
			}
			
		}
				
		return parsedList;
	}
	
	
	
	/**
	 * This Method is used to convert a Input string Int value to an Integer value.
	 * @param no
	 * @return
	 * @throws InvalidCronExpressionException
	 */
	private Integer parseNumber(String no) 	throws InvalidCronExpressionException
	{
        try {
            return Integer.parseInt(no);
        } catch (NumberFormatException nfe) {
            throw new InvalidCronExpressionException( no +" is an invalid number in the given expression" + ": " + nfe.getMessage());
        }
    }

}