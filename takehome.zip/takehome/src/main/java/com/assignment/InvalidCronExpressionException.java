package com.assignment;

public class InvalidCronExpressionException extends Exception {

	public InvalidCronExpressionException(String message) {
		super(message);
	}
}
